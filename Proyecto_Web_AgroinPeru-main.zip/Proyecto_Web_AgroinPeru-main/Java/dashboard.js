/* ==========================================================================
   DASHBOARD.JS — AgroinPeru Admin
   Lógica de gráficos, tabla y actividad del dashboard
   ========================================================================== */

/* ── DATOS SIMULADOS (reemplazar con fetch a tu API cuando corresponda) ──── */
const DATOS = {
    // Últimos 6 meses de ingresos en soles
    ingresos: {
        labels:  ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
        meses:   [18400, 22100, 19800, 27300, 24600, 31250],
        semanas: [5200,  6300,  7100,  8900,  7800,  9600],
        dias:    [980,   1200,  1050,  1400,  1150,  1320]
    },
    // Distribución de ventas por tipo
    tiposVenta: {
        labels: ['Boletas', 'Facturas', 'Proformas'],
        data:   [54, 34, 12]
    },
    // Ventas recientes
    ventasRecientes: [
        { doc:'B001-000012', cliente:'Juan Pérez García',    tipo:'boleta',  monto:205.00,  estado:'emitida', fecha:'08/06/2025 14:30' },
        { doc:'F001-000005', cliente:'Agro Sur S.A.C.',      tipo:'factura', monto:1660.00, estado:'emitida', fecha:'08/06/2025 11:15' },
        { doc:'B001-000011', cliente:'Rosa Torres Luna',     tipo:'boleta',  monto:88.50,   estado:'emitida', fecha:'07/06/2025 09:40' },
        { doc:'F001-000004', cliente:'Riego Norte E.I.R.L.',  tipo:'factura', monto:3200.00, estado:'emitida', fecha:'07/06/2025 08:00' },
        { doc:'B001-000010', cliente:'Carlos Mamani Huanca', tipo:'boleta',  monto:152.00,  estado:'anulada', fecha:'06/06/2025 16:55' },
    ],
    // Stock bajo
    stockBajo: [
        { nombre:'Bomba Superficial 1HP',  sku:'BOM-SUP-1HP',  qty:25, max:100 },
        { nombre:'Válvula Solenoide 24V',  sku:'VAL-SOL-24V',  qty:40, max:150 },
        { nombre:'Filtro de Disco 2"',     sku:'FIL-DIS-2P',   qty:18, max:80  },
        { nombre:'Aspersor 360° Metal',    sku:'ASP-360-MET',  qty:30, max:200 },
    ],
    // Actividad reciente
    actividad: [
        { icono:'fa-cart-shopping', bg:'#dcfce7', color:'#16a34a', texto:'Nueva venta registrada — Boleta B001-000012 por S/ 205.00',       tiempo:'hace 2 h' },
        { icono:'fa-user-plus',     bg:'#dbeafe', color:'#2563eb', texto:'Nuevo usuario creado — María Salas (cajero)',                      tiempo:'hace 4 h' },
        { icono:'fa-boxes-stacked', bg:'#fef3c7', color:'#d97706', texto:'Stock actualizado — Tubería PVC 3/4" (+200 unidades)',             tiempo:'hace 6 h' },
        { icono:'fa-file-invoice',  bg:'#f5f3ff', color:'#6d28d9', texto:'Factura F001-000004 emitida — Riego Norte E.I.R.L. S/ 3,200.00',  tiempo:'ayer' },
        { icono:'fa-rotate-left',   bg:'#fee2e2', color:'#dc2626', texto:'Devolución registrada — Aspersor 360° x2 und',                    tiempo:'ayer' },
    ]
};

/* ── UTILIDADES ──────────────────────────────────────────────────────────── */
const fmt = (n) => 'S/ ' + n.toLocaleString('es-PE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* ── FECHA EN EL HEADER ──────────────────────────────────────────────────── */
function setFecha() {
    const el = document.getElementById('dashFecha');
    if (!el) return;
    const now = new Date();
    const dias   = ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado'];
    const meses  = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
    el.textContent = `${dias[now.getDay()]}, ${now.getDate()} de ${meses[now.getMonth()]} de ${now.getFullYear()}`;
}

/* ── GRÁFICO DE INGRESOS (línea / área) ─────────────────────────────────── */
let ingresosChart = null;

function initIngresosChart(periodo = 'meses') {
    const ctx = document.getElementById('ingresosChart');
    if (!ctx) return;

    const labels = periodo === 'meses'  ? DATOS.ingresos.labels
                 : periodo === 'semanas'? ['S1','S2','S3','S4','S5','S6']
                 : ['Lun','Mar','Mié','Jue','Vie','Sáb'];

    const data = DATOS.ingresos[periodo];

    if (ingresosChart) ingresosChart.destroy();

    ingresosChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: 'Ingresos (S/)',
                data,
                borderColor: '#16a34a',
                backgroundColor: 'rgba(22,163,74,0.10)',
                pointBackgroundColor: '#16a34a',
                pointRadius: 4,
                pointHoverRadius: 6,
                fill: true,
                tension: 0.4,
                borderWidth: 2.5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    callbacks: {
                        label: ctx => ' ' + fmt(ctx.parsed.y)
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: v => 'S/ ' + (v >= 1000 ? (v/1000).toFixed(0)+'k' : v),
                        font: { size: 11 }
                    },
                    grid: { color: '#f3f4f6' }
                },
                x: {
                    ticks: { font: { size: 11 } },
                    grid:  { display: false }
                }
            }
        }
    });
}

/* ── GRÁFICO DE TIPOS DE VENTA (donut) ──────────────────────────────────── */
function initTiposChart() {
    const ctx = document.getElementById('tiposChart');
    if (!ctx) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: DATOS.tiposVenta.labels,
            datasets: [{
                data: DATOS.tiposVenta.data,
                backgroundColor: ['#3b82f6','#8b5cf6','#f59e0b'],
                borderWidth: 0,
                hoverOffset: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        boxWidth: 12,
                        padding: 14,
                        font: { size: 11 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: ctx => ` ${ctx.label}: ${ctx.parsed}%`
                    }
                }
            },
            cutout: '65%'
        }
    });
}

/* ── TABLA DE VENTAS RECIENTES ───────────────────────────────────────────── */
function renderVentas() {
    const tbody = document.getElementById('ventasTbody');
    if (!tbody) return;

    tbody.innerHTML = DATOS.ventasRecientes.map(v => `
        <tr>
            <td><span class="fw-semibold" style="font-family:monospace;font-size:0.78rem;">${v.doc}</span></td>
            <td>${v.cliente}</td>
            <td><span class="badge-${v.tipo}">${v.tipo.charAt(0).toUpperCase()+v.tipo.slice(1)}</span></td>
            <td class="fw-bold text-end">${fmt(v.monto)}</td>
            <td><span class="badge-${v.estado}">${v.estado.charAt(0).toUpperCase()+v.estado.slice(1)}</span></td>
            <td style="font-size:0.7rem;color:#9ca3af;font-family:monospace;">${v.fecha}</td>
        </tr>
    `).join('');
}

/* ── STOCK BAJO ──────────────────────────────────────────────────────────── */
function renderStock() {
    const wrap = document.getElementById('stockWrap');
    if (!wrap) return;

    wrap.innerHTML = DATOS.stockBajo.map(s => {
        const pct   = Math.round((s.qty / s.max) * 100);
        const nivel = pct < 25 ? 'critical' : 'warning';
        const color = pct < 25 ? '#ef4444' : '#f59e0b';
        return `
        <div class="stock-item">
            <div>
                <div class="stock-name">${s.nombre}</div>
                <div class="stock-sku">${s.sku}</div>
                <div class="stock-bar-wrap mt-2">
                    <div class="stock-bar" style="width:${pct}%;background:${color};"></div>
                </div>
            </div>
            <span class="stock-qty ${nivel}">Stock: ${s.qty}</span>
        </div>`;
    }).join('');
}

/* ── ACTIVIDAD RECIENTE ──────────────────────────────────────────────────── */
function renderActividad() {
    const wrap = document.getElementById('actividadWrap');
    if (!wrap) return;

    wrap.innerHTML = DATOS.actividad.map(a => `
        <div class="activity-item">
            <div class="activity-icon" style="background:${a.bg};color:${a.color};">
                <i class="fa-solid ${a.icono}"></i>
            </div>
            <div>
                <div class="activity-text">${a.texto}</div>
                <div class="activity-time">${a.tiempo}</div>
            </div>
        </div>
    `).join('');
}

/* ── TABS DE PERIODO DEL GRÁFICO ─────────────────────────────────────────── */
function initTabs() {
    document.querySelectorAll('.chart-tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.chart-tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            initIngresosChart(btn.dataset.periodo);
        });
    });
}

/* ── SIDEBAR TOGGLE (móvil) ──────────────────────────────────────────────── */
function initSidebar() {
    const btn = document.getElementById('sidebarToggle');
    if (btn) {
        btn.addEventListener('click', () => {
            document.querySelector('.admin-sidebar')?.classList.toggle('active');
        });
    }
}

/* ── INIT PRINCIPAL ──────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
    setFecha();
    initIngresosChart('meses');
    initTiposChart();
    renderVentas();
    renderStock();
    renderActividad();
    initTabs();
    initSidebar();
    hideLoader();
});