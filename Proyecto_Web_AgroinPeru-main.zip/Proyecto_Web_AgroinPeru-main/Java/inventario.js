/**
 * inventario.js — AgroinPeru Admin
 * RF35: Búsqueda de productos
 * RF36: Registrar, actualizar, eliminar con QR
 * RF37: Sincronización con ventas
 */

document.addEventListener('DOMContentLoaded', () => {

    /* ===== ESTADO ===== */
    let productoEditando = null; // código original al editar
    let qrStream = null;

    /* ===== INYECTAR HTML DE MODALES ===== */
    document.body.insertAdjacentHTML('beforeend', `

    <!-- MODAL PRODUCTO (nuevo / editar) -->
    <div class="modal fade" id="modalProducto" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
          <div class="modal-header bg-success text-white">
            <h5 class="modal-title fw-bold" id="modalProductoTitulo"><i class="fa-solid fa-plus me-2"></i>Nuevo Producto</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-4">
            <div class="mb-3">
              <label class="form-label fw-semibold small">Código <span class="text-danger">*</span></label>
              <div class="input-group">
                <input type="text" id="inp-codigo" class="form-control" placeholder="Ej: TUB-PVC-1/2" maxlength="30">
                <button class="btn btn-outline-success" id="btn-qr-codigo" title="Escanear QR"><i class="fa-solid fa-qrcode"></i></button>
              </div>
              <div class="form-text text-muted">Puedes escanear el QR del producto para rellenar el código.</div>
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Nombre <span class="text-danger">*</span></label>
              <input type="text" id="inp-nombre" class="form-control" placeholder="Nombre del producto" maxlength="80">
            </div>
            <div class="mb-3">
              <label class="form-label fw-semibold small">Categoría <span class="text-danger">*</span></label>
              <input type="text" id="inp-categoria" class="form-control" placeholder="Ej: Tuberías PVC" maxlength="40">
            </div>
            <div class="row g-3">
              <div class="col-6">
                <label class="form-label fw-semibold small">Precio (S/) <span class="text-danger">*</span></label>
                <input type="number" id="inp-precio" class="form-control" placeholder="0.00" min="0" step="0.01">
              </div>
              <div class="col-6">
                <label class="form-label fw-semibold small">Stock <span class="text-danger">*</span></label>
                <input type="number" id="inp-stock" class="form-control" placeholder="0" min="0" step="1">
              </div>
            </div>
            <div id="modal-error" class="alert alert-danger mt-3 d-none py-2 small"></div>
          </div>
          <div class="modal-footer border-0 pt-0">
            <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
            <button class="btn btn-success px-4" id="btn-guardar-producto"><i class="fa-solid fa-floppy-disk me-2"></i>Guardar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- MODAL QR SCANNER -->
    <div class="modal fade" id="modalQR" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow">
          <div class="modal-header bg-dark text-white">
            <h5 class="modal-title small fw-bold"><i class="fa-solid fa-qrcode me-2"></i>Escanear Código QR</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-3 text-center">
            <video id="qr-video" class="w-100 rounded" style="max-height:260px; background:#000;" playsinline autoplay muted></video>
            <div id="qr-status" class="mt-2 small text-muted">Iniciando cámara...</div>
            <div class="mt-2">
              <input type="text" id="qr-manual" class="form-control form-control-sm text-center" placeholder="O escribe el código manualmente">
              <button class="btn btn-success btn-sm mt-2 w-100" id="btn-qr-manual-ok">Usar este código</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- MODAL CONFIRMAR ELIMINAR -->
    <div class="modal fade" id="modalEliminar" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow">
          <div class="modal-body p-4 text-center">
            <div class="text-danger mb-3" style="font-size:2.5rem"><i class="fa-solid fa-triangle-exclamation"></i></div>
            <h5 class="fw-bold">¿Eliminar producto?</h5>
            <p class="text-muted small mb-0" id="eliminar-desc">Se eliminará permanentemente.</p>
          </div>
          <div class="modal-footer border-0 justify-content-center gap-3">
            <button class="btn btn-outline-secondary px-4" data-bs-dismiss="modal">Cancelar</button>
            <button class="btn btn-danger px-4" id="btn-confirmar-eliminar"><i class="fa-solid fa-trash me-1"></i>Eliminar</button>
          </div>
        </div>
      </div>
    </div>

    <!-- TOAST NOTIFICACIÓN -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index:9999">
      <div id="toast-inv" class="toast align-items-center text-white border-0" role="alert">
        <div class="d-flex">
          <div class="toast-body fw-semibold" id="toast-msg">✓ Acción completada.</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    </div>
    `);

    /* ===== REFERENCIAS DOM ===== */
    const tbody           = document.querySelector('.admin-table tbody');
    const inputBuscar     = document.querySelector('input[placeholder="Buscar producto..."]');
    const btnNuevo        = document.querySelector('.btn-success.rounded-3');
    const modalProducto   = new bootstrap.Modal('#modalProducto');
    const modalQR         = new bootstrap.Modal('#modalQR');
    const modalEliminar   = new bootstrap.Modal('#modalEliminar');
    const toastEl         = document.getElementById('toast-inv');
    const toast           = new bootstrap.Toast(toastEl, { delay: 3000 });

    /* ===== HELPERS ===== */
    function mostrarToast(msg, tipo = 'success') {
        const colores = { success: 'bg-success', danger: 'bg-danger', warning: 'bg-warning text-dark' };
        toastEl.className = `toast align-items-center text-white border-0 ${colores[tipo] || 'bg-success'}`;
        document.getElementById('toast-msg').textContent = msg;
        toast.show();
    }

    function badgeStock(stock) {
        if (stock <= 10) return `<span class="badge bg-danger rounded-circle p-2 font-monospace fw-bold" style="width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;">${stock}</span>`;
        if (stock <= 50) return `<span class="badge bg-warning text-dark rounded-circle p-2 font-monospace fw-bold" style="width:32px;height:32px;display:inline-flex;align-items:center;justify-content:center;">${stock}</span>`;
        return `<span class="font-monospace text-muted small">${stock}</span>`;
    }

    /* ===== RENDERIZAR TABLA ===== */
    function renderTabla(lista) {
        if (!lista.length) {
            tbody.innerHTML = `<tr><td colspan="6" class="text-center text-muted py-5"><i class="fa-solid fa-box-open me-2"></i>Sin productos registrados.</td></tr>`;
            return;
        }
        tbody.innerHTML = lista.map(p => `
            <tr data-codigo="${p.codigo}">
                <td class="font-monospace text-muted small">${p.codigo}</td>
                <td class="fw-bold small">${p.nombre}</td>
                <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill px-3 py-1 fw-semibold" style="font-size:11px">${p.categoria}</span></td>
                <td class="fw-semibold">S/ ${p.precio.toFixed(2)}</td>
                <td class="text-center">${badgeStock(p.stock)}</td>
                <td class="text-center">
                    <button class="btn btn-sm btn-link text-primary p-1 btn-editar" title="Editar"><i class="fa-solid fa-pen"></i></button>
                    <button class="btn btn-sm btn-link text-danger p-1 btn-eliminar" title="Eliminar"><i class="fa-solid fa-trash"></i></button>
                </td>
            </tr>`).join('');
    }

    function cargarTabla(filtro = '') {
        const lista = ProductosDB.getAll().filter(p =>
            !filtro || p.nombre.toLowerCase().includes(filtro) || p.codigo.toLowerCase().includes(filtro) || p.categoria.toLowerCase().includes(filtro)
        );
        renderTabla(lista);
    }

    /* ===== BUSCAR ===== */
    inputBuscar?.addEventListener('input', e => cargarTabla(e.target.value.toLowerCase().trim()));

    /* ===== NUEVO PRODUCTO ===== */
    btnNuevo?.addEventListener('click', () => {
        productoEditando = null;
        document.getElementById('modalProductoTitulo').innerHTML = '<i class="fa-solid fa-plus me-2"></i>Nuevo Producto';
        ['codigo', 'nombre', 'categoria', 'precio', 'stock'].forEach(id => document.getElementById(`inp-${id}`).value = '');
        document.getElementById('inp-codigo').readOnly = false;
        document.getElementById('modal-error').classList.add('d-none');
        modalProducto.show();
    });

    /* ===== GUARDAR (nuevo o editar) ===== */
    document.getElementById('btn-guardar-producto').addEventListener('click', () => {
        const codigo    = document.getElementById('inp-codigo').value.trim().toUpperCase();
        const nombre    = document.getElementById('inp-nombre').value.trim();
        const categoria = document.getElementById('inp-categoria').value.trim();
        const precio    = parseFloat(document.getElementById('inp-precio').value);
        const stock     = parseInt(document.getElementById('inp-stock').value);
        const errEl     = document.getElementById('modal-error');

        if (!codigo || !nombre || !categoria || isNaN(precio) || isNaN(stock)) {
            errEl.textContent = 'Completa todos los campos obligatorios.';
            errEl.classList.remove('d-none');
            return;
        }
        if (precio < 0 || stock < 0) {
            errEl.textContent = 'Precio y stock deben ser valores positivos.';
            errEl.classList.remove('d-none');
            return;
        }
        errEl.classList.add('d-none');

        const prod = { codigo, nombre, categoria, precio, stock };
        let res;
        if (productoEditando) {
            res = ProductosDB.actualizar(productoEditando, prod);
        } else {
            res = ProductosDB.agregar(prod);
        }

        if (!res.ok) {
            errEl.textContent = res.msg;
            errEl.classList.remove('d-none');
            return;
        }

        modalProducto.hide();
        cargarTabla();
        mostrarToast(productoEditando ? '✓ Producto actualizado y sincronizado con ventas.' : '✓ Producto registrado y disponible en ventas.');
    });

    /* ===== EDITAR / ELIMINAR (delegación) ===== */
    tbody.addEventListener('click', e => {
        const fila = e.target.closest('tr[data-codigo]');
        if (!fila) return;
        const codigo = fila.dataset.codigo;

        if (e.target.closest('.btn-editar')) {
            const p = ProductosDB.buscarPorCodigo(codigo);
            if (!p) return;
            productoEditando = codigo;
            document.getElementById('modalProductoTitulo').innerHTML = '<i class="fa-solid fa-pen me-2"></i>Editar Producto';
            document.getElementById('inp-codigo').value    = p.codigo;
            document.getElementById('inp-codigo').readOnly = true; // código no cambia al editar
            document.getElementById('inp-nombre').value    = p.nombre;
            document.getElementById('inp-categoria').value = p.categoria;
            document.getElementById('inp-precio').value    = p.precio;
            document.getElementById('inp-stock').value     = p.stock;
            document.getElementById('modal-error').classList.add('d-none');
            modalProducto.show();
        }

        if (e.target.closest('.btn-eliminar')) {
            const p = ProductosDB.buscarPorCodigo(codigo);
            document.getElementById('eliminar-desc').textContent = `"${p?.nombre || codigo}" se eliminará permanentemente y se quitará del módulo de ventas.`;
            document.getElementById('btn-confirmar-eliminar').dataset.codigo = codigo;
            modalEliminar.show();
        }
    });

    document.getElementById('btn-confirmar-eliminar').addEventListener('click', function () {
        ProductosDB.eliminar(this.dataset.codigo);
        modalEliminar.hide();
        cargarTabla();
        mostrarToast('🗑 Producto eliminado y sincronizado.', 'danger');
    });

    /* ===== QR SCANNER ===== */
    // Abre modal QR al clicar el botón de código
    document.getElementById('btn-qr-codigo').addEventListener('click', () => {
        document.getElementById('qr-manual').value = '';
        modalQR.show();
    });

    // Cuando el modal QR abre → pide cámara
    document.getElementById('modalQR').addEventListener('shown.bs.modal', iniciarQR);
    document.getElementById('modalQR').addEventListener('hidden.bs.modal', detenerQR);

    function iniciarQR() {
        const video  = document.getElementById('qr-video');
        const status = document.getElementById('qr-status');
        status.textContent = 'Iniciando cámara...';

        if (!navigator.mediaDevices?.getUserMedia) {
            status.textContent = '⚠ Cámara no disponible en este navegador. Usa el campo manual.';
            return;
        }

        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(stream => {
                qrStream = stream;
                video.srcObject = stream;
                status.textContent = '📷 Apunta al código QR del producto...';
                // Nota: para QR real se integraría jsQR. Aquí simulamos lectura manual.
            })
            .catch(() => {
                status.textContent = '⚠ No se pudo acceder a la cámara. Usa el campo manual.';
            });
    }

    function detenerQR() {
        if (qrStream) {
            qrStream.getTracks().forEach(t => t.stop());
            qrStream = null;
        }
    }

    // Botón manual QR
    document.getElementById('btn-qr-manual-ok').addEventListener('click', () => {
        const val = document.getElementById('qr-manual').value.trim().toUpperCase();
        if (!val) return;
        document.getElementById('inp-codigo').value = val;

        // Si ya existe → auto-rellenar
        const existente = ProductosDB.buscarPorCodigo(val);
        if (existente) {
            document.getElementById('inp-nombre').value    = existente.nombre;
            document.getElementById('inp-categoria').value = existente.categoria;
            document.getElementById('inp-precio').value    = existente.precio;
            document.getElementById('inp-stock').value     = existente.stock;
        }

        modalQR.hide();
        mostrarToast('✓ Código QR cargado en el formulario.', 'success');
    });

    /* ===== SINCRONIZACIÓN ===== */
    // Si ventas actualiza stock en otra pestaña
    window.addEventListener('storage', e => {
        if (e.key === 'agroinperu_productos') cargarTabla();
    });

    /* ===== CARGA INICIAL ===== */
    cargarTabla();
});