/* ==========================================================================
   USUARIOS.JS — AgroinPeru Admin
   Lógica del modal "Nuevo Usuario" / "Editar Usuario", validaciones,
   alta dinámica de tarjetas y acciones de editar/eliminar
   (RF31, RF32, RF33, RF34)
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {

    const modalEl       = document.getElementById('modalNuevoUsuario');
    const modal         = modalEl ? new bootstrap.Modal(modalEl) : null;
    const form          = document.getElementById('formNuevoUsuario');
    const inputNombre   = document.getElementById('nuevoNombre');
    const inputCorreo   = document.getElementById('nuevoCorreo');
    const inputPass     = document.getElementById('nuevaContrasena');
    const selectRol     = document.getElementById('nuevoRol');
    const togglePass    = document.getElementById('togglePass');
    const btnGuardar    = document.getElementById('btnGuardarUsuario');
    const listaUsuarios = document.querySelector('.row.g-4');
    const modalTitle    = modalEl ? modalEl.querySelector('.modal-title') : null;
    const passHint      = inputPass ? inputPass.closest('.mb-3').querySelector('small') : null;

    // Modal de confirmación de eliminación
    const modalEliminarEl   = document.getElementById('modalConfirmarEliminar');
    const modalEliminar     = modalEliminarEl ? new bootstrap.Modal(modalEliminarEl) : null;
    const nombreEliminarEl  = document.getElementById('nombreUsuarioEliminar');
    const btnConfirmarEliminar = document.getElementById('btnConfirmarEliminar');

    // Referencia a la tarjeta que se está editando (null = creando un usuario nuevo)
    let usuarioEditando = null;
    // Referencia a la columna (tarjeta) pendiente de eliminar
    let colAEliminar = null;

    /* ── MOSTRAR / OCULTAR CONTRASEÑA ───────────────────────────────────── */
    if (togglePass && inputPass) {
        togglePass.addEventListener('click', () => {
            const icon = togglePass.querySelector('i');
            const isPassword = inputPass.type === 'password';
            inputPass.type = isPassword ? 'text' : 'password';
            icon.classList.toggle('fa-eye');
            icon.classList.toggle('fa-eye-slash');
        });
    }

    /* ── LIMPIAR ESTADOS DE ERROR AL ESCRIBIR ───────────────────────────── */
    [inputNombre, inputCorreo, inputPass, selectRol].forEach(campo => {
        if (!campo) return;
        campo.addEventListener('input', () => campo.classList.remove('is-invalid'));
        campo.addEventListener('change', () => campo.classList.remove('is-invalid'));
    });

    /* ── RESETEAR FORMULARIO AL CERRAR EL MODAL ─────────────────────────── */
    if (modalEl) {
        modalEl.addEventListener('hidden.bs.modal', () => {
            form.reset();
            form.querySelectorAll('.is-invalid').forEach(el => el.classList.remove('is-invalid'));

            if (inputPass.type === 'text') {
                inputPass.type = 'password';
                togglePass.querySelector('i').classList.replace('fa-eye-slash', 'fa-eye');
            }

            // Volver al modo "Nuevo Usuario"
            usuarioEditando = null;
            inputPass.required = true;
            if (passHint) passHint.textContent = 'Mínimo 6 caracteres.';
            if (modalTitle) modalTitle.innerHTML = '<i class="fa-solid fa-user-plus text-success me-2"></i>Nuevo Usuario';
            if (btnGuardar) btnGuardar.innerHTML = '<i class="fa-solid fa-floppy-disk me-2"></i>Guardar';
        });
    }

    /* ── UTILIDADES ──────────────────────────────────────────────────────── */
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    function correoYaExiste(correo, cardActual = null) {
        const spans = Array.from(document.querySelectorAll('.stat-card .flex-grow-1 .text-muted span'))
            .filter(span => !cardActual || !cardActual.contains(span))
            .map(span => span.textContent.trim().toLowerCase())
            .filter(t => t.includes('@'));
        return spans.includes(correo.toLowerCase());
    }

    function marcarError(input, mensaje) {
        input.classList.add('is-invalid');
        let feedback = input.parentElement.querySelector('.invalid-feedback');
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            input.parentElement.appendChild(feedback);
        }
        feedback.textContent = mensaje;
    }

    function fechaHoy() {
        const d = new Date();
        const pad = n => String(n).padStart(2, '0');
        return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
    }

    /* ── TOAST DE CONFIRMACIÓN ───────────────────────────────────────────── */
    function mostrarToast(mensaje, tipo = 'success') {
        let contenedor = document.getElementById('toastContainer');
        if (!contenedor) {
            contenedor = document.createElement('div');
            contenedor.id = 'toastContainer';
            contenedor.className = 'toast-container position-fixed bottom-0 end-0 p-3';
            contenedor.style.zIndex = 1080;
            document.body.appendChild(contenedor);
        }

        const colores = { success: 'bg-success', danger: 'bg-danger' };
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white ${colores[tipo] || colores.success} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body fw-semibold">${mensaje}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>`;
        contenedor.appendChild(toast);

        const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
        bsToast.show();
        toast.addEventListener('hidden.bs.toast', () => toast.remove());
    }

    /* ── VALIDACIÓN Y GUARDADO (CREAR o EDITAR) ─────────────────────────── */
    if (btnGuardar) {
        btnGuardar.addEventListener('click', () => {

            let valido = true;

            // Nombre
            if (!inputNombre.value.trim()) {
                marcarError(inputNombre, 'Ingresa el nombre completo del usuario.');
                valido = false;
            }

            // Correo
            const correo = inputCorreo.value.trim();
            if (!correo || !emailRegex.test(correo)) {
                marcarError(inputCorreo, 'Ingresa un correo electrónico válido.');
                valido = false;
            } else if (correoYaExiste(correo, usuarioEditando)) {
                marcarError(inputCorreo, 'Ya existe un usuario registrado con este correo.');
                valido = false;
            }

            // Contraseña: obligatoria al crear, opcional al editar
            const passVacia = inputPass.value.length === 0;
            if (!usuarioEditando && inputPass.value.length < 6) {
                marcarError(inputPass, 'La contraseña debe tener mínimo 6 caracteres.');
                valido = false;
            } else if (usuarioEditando && !passVacia && inputPass.value.length < 6) {
                marcarError(inputPass, 'La contraseña debe tener mínimo 6 caracteres.');
                valido = false;
            }

            // Rol
            if (!selectRol.value) {
                marcarError(selectRol, 'Selecciona un rol para el usuario.');
                valido = false;
            }

            if (!valido) return;

            const datosUsuario = {
                nombre: inputNombre.value.trim(),
                correo: correo,
                contrasena: inputPass.value, // vacío en edición = no cambiar
                rol: selectRol.value
            };

            if (usuarioEditando) {
                // ── MODO EDICIÓN (RF33) ──
                // TODO: fetch PUT /admin/usuarios/:id con datosUsuario
                actualizarTarjetaUsuario(usuarioEditando, datosUsuario);
                modal.hide();
                mostrarToast(`Usuario "${datosUsuario.nombre}" actualizado correctamente.`);
            } else {
                // ── MODO CREACIÓN (RF32) ──
                // TODO: fetch POST /admin/usuarios con datosUsuario
                agregarTarjetaUsuario(datosUsuario);
                modal.hide();
                mostrarToast(`Usuario "${datosUsuario.nombre}" creado correctamente.`);
            }
        });
    }

    /* ── CREAR TARJETA DE USUARIO NUEVO (RF31) ──────────────────────────── */
    function agregarTarjetaUsuario(usuario) {
        const esAdmin  = usuario.rol === 'admin';
        const color    = esAdmin ? 'success' : 'primary';
        const icono    = esAdmin ? 'fa-shield-halved' : 'fa-user';

        const col = document.createElement('div');
        col.className = 'col-12 col-md-6 col-xl-4';
        col.innerHTML = `
            <div class="card stat-card p-4 bg-white">
                <div class="d-flex align-items-start gap-3">
                    <div class="bg-${color} bg-opacity-10 text-${color} rounded-circle d-flex align-items-center justify-content-center shadow-sm" style="width: 48px; height: 48px; flex-shrink: 0;">
                        <i class="fa-solid ${icono} fs-5"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h4 class="h6 fw-bold m-0 text-dark">${usuario.nombre}</h4>
                        <span class="badge bg-${color} bg-opacity-10 text-${color} rounded-pill px-2.5 py-0.5 my-2 fw-semibold font-monospace" style="font-size: 10px;">${usuario.rol}</span>
                        <div class="text-muted small d-flex flex-column gap-1 mt-1">
                            <span><i class="fa-regular fa-envelope me-2"></i>${usuario.correo}</span>
                            <span><i class="fa-regular fa-calendar-days me-2"></i>Desde: ${fechaHoy()}</span>
                        </div>
                    </div>
                </div>
                <div class="d-flex justify-content-between align-items-center mt-4 pt-3 border-top">
                    <span class="badge bg-success bg-opacity-10 text-success rounded-pill px-2.5 py-1">Activo</span>
                    <div>
                        <button class="btn btn-link text-primary p-1 me-2 btn-edit"><i class="fa-solid fa-pen"></i></button>
                        <button class="btn btn-link text-danger p-1 btn-delete"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>
            </div>`;

        listaUsuarios.appendChild(col);
    }

    /* ── ACTUALIZAR TARJETA EXISTENTE (RF33) ────────────────────────────── */
    function actualizarTarjetaUsuario(card, usuario) {
        const esAdmin = usuario.rol === 'admin';
        const color   = esAdmin ? 'success' : 'primary';
        const icono   = esAdmin ? 'fa-shield-halved' : 'fa-user';

        // Ícono circular
        const iconWrap = card.querySelector('.rounded-circle');
        iconWrap.className = `bg-${color} bg-opacity-10 text-${color} rounded-circle d-flex align-items-center justify-content-center shadow-sm`;
        iconWrap.style.width = '48px';
        iconWrap.style.height = '48px';
        iconWrap.style.flexShrink = '0';
        const icon = iconWrap.querySelector('i');
        if (icon) icon.className = `fa-solid ${icono} fs-5`;

        // Nombre
        const nombreEl = card.querySelector('h4');
        if (nombreEl) nombreEl.textContent = usuario.nombre;

        // Badge de rol (el que tiene font-monospace, distinto del badge "Activo/Inactivo")
        const rolBadge = card.querySelector('.flex-grow-1 .badge.font-monospace');
        if (rolBadge) {
            rolBadge.className = `badge bg-${color} bg-opacity-10 text-${color} rounded-pill px-2.5 py-0.5 my-2 fw-semibold font-monospace`;
            rolBadge.style.fontSize = '10px';
            rolBadge.textContent = usuario.rol;
        }

        // Correo (primer span dentro del bloque de info)
        const infoSpans = card.querySelectorAll('.flex-grow-1 .text-muted span');
        if (infoSpans[0]) {
            infoSpans[0].innerHTML = `<i class="fa-regular fa-envelope me-2"></i>${usuario.correo}`;
        }
    }

    /* ── ABRIR MODAL EN MODO EDICIÓN ─────────────────────────────────────── */
    function abrirEdicion(card) {
        usuarioEditando = card;

        const nombre   = card.querySelector('h4')?.textContent.trim() || '';
        const rolBadge = card.querySelector('.flex-grow-1 .badge.font-monospace');
        const rol      = rolBadge ? rolBadge.textContent.trim().toLowerCase() : 'cajero';
        const infoSpans = card.querySelectorAll('.flex-grow-1 .text-muted span');
        const correo   = infoSpans[0]?.textContent.trim() || '';

        inputNombre.value = nombre;
        inputCorreo.value = correo;
        selectRol.value   = (rol === 'admin' || rol === 'cajero') ? rol : '';
        inputPass.value   = '';
        inputPass.required = false;

        if (passHint) passHint.textContent = 'Déjalo en blanco para mantener la contraseña actual.';
        if (modalTitle) modalTitle.innerHTML = '<i class="fa-solid fa-user-pen text-primary me-2"></i>Editar Usuario';
        if (btnGuardar) btnGuardar.innerHTML = '<i class="fa-solid fa-floppy-disk me-2"></i>Guardar cambios';

        modal.show();
    }

    /* ── EDITAR / ELIMINAR — delegación de eventos por ícono ─────────────── */
    if (listaUsuarios) {
        listaUsuarios.addEventListener('click', (e) => {
            const btn = e.target.closest('button');
            if (!btn) return;

            // Editar (RF33) — botón con ícono fa-pen
            if (btn.querySelector('.fa-pen')) {
                const card = btn.closest('.card');
                if (card) abrirEdicion(card);
                return;
            }

            // Eliminar — botón con ícono fa-trash → abre modal de confirmación (RF34)
            if (btn.querySelector('.fa-trash')) {
                const col    = btn.closest('.col-12');
                const nombre = col.querySelector('h4')?.textContent.trim() || 'este usuario';

                colAEliminar = col;
                if (nombreEliminarEl) nombreEliminarEl.textContent = nombre;
                if (modalEliminar) modalEliminar.show();
            }
        });
    }

    /* ── CONFIRMAR ELIMINACIÓN DESDE EL MODAL ───────────────────────────── */
    if (btnConfirmarEliminar) {
        btnConfirmarEliminar.addEventListener('click', () => {
            if (!colAEliminar) return;

            const nombre = colAEliminar.querySelector('h4')?.textContent.trim() || 'Usuario';

            // TODO: fetch DELETE /admin/usuarios/:id
            colAEliminar.remove();
            colAEliminar = null;

            modalEliminar.hide();
            mostrarToast(`Usuario "${nombre}" eliminado.`, 'danger');
        });
    }

    // Si se cierra el modal sin confirmar, limpiar la referencia
    if (modalEliminarEl) {
        modalEliminarEl.addEventListener('hidden.bs.modal', () => {
            colAEliminar = null;
        });
    }

});