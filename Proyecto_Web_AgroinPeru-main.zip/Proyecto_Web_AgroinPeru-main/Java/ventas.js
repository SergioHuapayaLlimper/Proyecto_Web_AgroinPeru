/**
 * ventas.js — AgroinPeru POS
 * RF35: Listado de productos con búsqueda
 * RF36: Lectura de código QR para agregar productos
 * RF37: Descuenta stock al confirmar venta
 */

document.addEventListener('DOMContentLoaded', () => {

    /* ============================================================
       ESTADO
    ============================================================ */
    let tabActual  = 'boleta'; // 'boleta' | 'factura' | 'proforma'
    let carrito    = [];
    let metodoPago = 'efectivo';
    let ventaFinalizada = false;
    let qrStream   = null;
    let contadores = JSON.parse(localStorage.getItem('agroinperu_contadores') || '{"boleta":1,"factura":1,"proforma":1}');

    /* ============================================================
       ACTUALIZAR FECHA/HORA
    ============================================================ */
    function actualizarFecha() {
        const ahora = new Date();
        const fmt = ahora.toLocaleString('es-PE', { day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit', hour12:true });
        const el = document.getElementById('inp-fecha');
        if (el) el.value = fmt;
    }
    actualizarFecha();
    setInterval(actualizarFecha, 60000);

    /* ============================================================
       INYECTAR MODALES
    ============================================================ */
    document.body.insertAdjacentHTML('beforeend', `

    <!-- MODAL QR VENTAS -->
    <div class="modal fade" id="modalQRVentas" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered modal-sm">
        <div class="modal-content border-0 shadow">
          <div class="modal-header bg-dark text-white">
            <h5 class="modal-title small fw-bold"><i class="fa-solid fa-qrcode me-2"></i>Escanear Código</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-3 text-center">
            <video id="qr-video-ventas" class="w-100 rounded" style="max-height:240px;background:#000;" playsinline autoplay muted></video>
            <div id="qr-status-ventas" class="mt-2 small text-muted">Iniciando cámara...</div>
            <div class="mt-2">
              <input type="text" id="qr-manual-ventas" class="form-control form-control-sm text-center" placeholder="O escribe el código manualmente">
              <button class="btn btn-success btn-sm mt-2 w-100" id="btn-qr-ventas-ok">+ Agregar Producto</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- MODAL PREVIEW TICKET -->
    <div class="modal fade" id="modalPreview" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered" style="max-width:360px">
        <div class="modal-content border-0 shadow">
          <div class="modal-header border-0 pb-0">
            <h5 class="modal-title fw-bold small">Vista Previa</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-3">
            <div id="ticket-preview" style="font-family:monospace;font-size:13px;background:#fff;padding:16px;border-radius:8px;border:1px dashed #ccc;white-space:pre-wrap;"></div>
          </div>
          <div class="modal-footer border-0 pt-0">
            <button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
            <button class="btn btn-dark px-4" id="btn-print-preview"><i class="fa-solid fa-print me-1"></i>Imprimir</button>
          </div>
        </div>
      </div>
    </div>

    <!-- MODAL BUSCAR PRODUCTO -->
    <div class="modal fade" id="modalBuscarProd" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
          <div class="modal-header">
            <h5 class="modal-title fw-bold small"><i class="fa-solid fa-search me-2"></i>Buscar Producto</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <input type="text" id="modal-buscar-inp" class="form-control mb-3" placeholder="Nombre, código o categoría...">
            <div id="modal-buscar-lista" style="max-height:320px;overflow-y:auto;"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- TOAST -->
    <div class="position-fixed bottom-0 end-0 p-3" style="z-index:9999">
      <div id="toast-ventas" class="toast align-items-center text-white border-0" role="alert">
        <div class="d-flex">
          <div class="toast-body fw-semibold" id="toast-ventas-msg">✓ Listo.</div>
          <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
      </div>
    </div>
    `);

    /* ============================================================
       HELPERS
    ============================================================ */
    const toastEl  = document.getElementById('toast-ventas');
    const toast    = new bootstrap.Toast(toastEl, { delay: 3500 });

    function mostrarToast(msg, tipo = 'success') {
        const clases = { success:'bg-success', danger:'bg-danger', warning:'bg-warning text-dark', info:'bg-info' };
        toastEl.className = `toast align-items-center text-white border-0 ${clases[tipo] || 'bg-success'}`;
        document.getElementById('toast-ventas-msg').textContent = msg;
        toast.show();
    }

    function numComprobante() {
        const prefijos = { boleta:'B001', factura:'F001', proforma:'PRO' };
        const n = String(contadores[tabActual]).padStart(6, '0');
        return `${prefijos[tabActual]}-${n}`;
    }

    function guardarContadores() {
        localStorage.setItem('agroinperu_contadores', JSON.stringify(contadores));
    }

    /* ============================================================
       TABS
    ============================================================ */
    const tabs = document.querySelectorAll('.nav-tabs .nav-link');

    tabs.forEach(tab => {
        tab.addEventListener('click', e => {
            e.preventDefault();
            const nombre = tab.textContent.trim().toLowerCase();
            if (nombre === tabActual) return;
            if (carrito.length > 0) {
                if (!confirm('Cambiar de pestaña vaciará el carrito actual. ¿Continuar?')) return;
            }
            tabActual = nombre;
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            carrito = [];
            ventaFinalizada = false;
            renderCarrito();
            actualizarComprobante();
            actualizarFormCliente();
            actualizarBotones();
        });
    });

    function actualizarComprobante() {
        const el = document.getElementById('inp-numero');
        if (el) el.value = numComprobante();
    }

    /* ============================================================
       FORMULARIO CLIENTE según TAB
    ============================================================ */
    function actualizarFormCliente() {
        const contenedor = document.getElementById('form-cliente');
        if (!contenedor) return;

        if (tabActual === 'proforma') {
            contenedor.innerHTML = `
            <div class="col-md-6">
              <label class="form-label text-muted small mb-1">Apellidos del Cliente</label>
              <input type="text" class="form-control" id="cli-apellidos" placeholder="Apellidos">
            </div>
            <div class="col-md-6">
              <label class="form-label text-muted small mb-1">Nombres del Cliente</label>
              <input type="text" class="form-control" id="cli-nombres" placeholder="Nombres">
            </div>`;
            return;
        }

        const opcionesDNI = tabActual === 'boleta'
            ? `<option value="DNI">DNI</option>
               <option value="RUC">RUC</option>
               <option value="sin_doc">Sin Documento</option>
               <option value="razon">Razón Social</option>`
            : `<option value="RUC">RUC</option>`; // Factura solo RUC

        contenedor.innerHTML = `
        <div class="col-md-4">
          <label class="form-label text-muted small mb-1">Tipo de Documento</label>
          <select class="form-select" id="cli-tipo-doc">${opcionesDNI}</select>
        </div>
        <div class="col-md-8">
          <label class="form-label text-muted small mb-1">
            ${tabActual === 'factura' ? 'Número de RUC' : 'Número según tipo'}
          </label>
          <div class="input-group">
            <input type="text" class="form-control" id="cli-numero-doc" placeholder="${tabActual === 'factura' ? 'RUC (11 dígitos)' : 'Número de documento'}">
            <button class="btn btn-success" type="button" id="btn-buscar-cliente"><i class="fa-solid fa-magnifying-glass"></i> Buscar</button>
          </div>
        </div>
        <div class="col-md-6">
          <label class="form-label text-muted small mb-1">Nombre / Razón Social</label>
          <input type="text" class="form-control bg-light" id="cli-nombre-auto" placeholder="Se completa automáticamente" readonly>
        </div>
        <div class="col-md-6">
          <label class="form-label text-muted small mb-1">Dirección</label>
          <input type="text" class="form-control bg-light" id="cli-dir-auto" placeholder="Se completa automáticamente" readonly>
        </div>`;

        // Cambio tipo doc actualiza placeholder
        document.getElementById('cli-tipo-doc')?.addEventListener('change', () => {
            const tipo = document.getElementById('cli-tipo-doc').value;
            const ph = { DNI:'DNI (8 dígitos)', RUC:'RUC (11 dígitos)', sin_doc:'Sin Documento', razon:'Razón Social' };
            document.getElementById('cli-numero-doc').placeholder = ph[tipo] || 'Número de documento';
            document.getElementById('cli-nombre-auto').value = '';
            document.getElementById('cli-dir-auto').value = '';
        });

        // Buscar cliente (simulado)
        document.getElementById('btn-buscar-cliente')?.addEventListener('click', buscarCliente);
    }

    // Simulación de búsqueda de clientes
    const CLIENTES_MOCK = {
        '12345678':  { nombre: 'Juan Pérez García',           dir: 'Av. Los Álamos 345, Lima' },
        '87654321':  { nombre: 'Ana Torres Vega',             dir: 'Jr. Moquegua 123, Lima'  },
        '20100130492': { nombre: 'Distribuidora Agro S.A.C.',  dir: 'Av. Industrial 890, Callao' },
        '20601234567': { nombre: 'Comercial Rural E.I.R.L.',   dir: 'Calle Las Flores 12, Surco' },
    };

    function buscarCliente() {
        const num    = document.getElementById('cli-numero-doc')?.value.trim();
        const tipo   = document.getElementById('cli-tipo-doc')?.value;
        const nomEl  = document.getElementById('cli-nombre-auto');
        const dirEl  = document.getElementById('cli-dir-auto');
        if (!num) { mostrarToast('Ingresa un número de documento.', 'warning'); return; }

        // Validación RUC para factura
        if (tabActual === 'factura' && num.length !== 11) {
            mostrarToast('La Factura requiere RUC de 11 dígitos.', 'danger'); return;
        }
        if (tipo === 'DNI' && num.length !== 8) {
            mostrarToast('El DNI debe tener 8 dígitos.', 'warning'); return;
        }

        const cliente = CLIENTES_MOCK[num];
        if (cliente) {
            nomEl.value = cliente.nombre;
            dirEl.value = cliente.dir;
            mostrarToast(`✓ Cliente encontrado: ${cliente.nombre}`);
        } else {
            nomEl.value = tipo === 'sin_doc' ? 'Cliente Genérico' : '— No encontrado —';
            dirEl.value = tipo === 'sin_doc' ? '—' : '';
            if (tipo !== 'sin_doc') mostrarToast('Cliente no encontrado en la base de datos.', 'warning');
        }
    }

    /* ============================================================
       CARRITO
    ============================================================ */
    function agregarProducto(codigo, cantidad = 1) {
        const p = ProductosDB.buscarPorCodigo(codigo.toUpperCase());
        if (!p) { mostrarToast('Producto no encontrado: ' + codigo, 'danger'); return; }
        if (p.stock <= 0) { mostrarToast(`Sin stock para "${p.nombre}".`, 'danger'); return; }

        const existente = carrito.find(x => x.codigo === p.codigo);
        if (existente) {
            if (existente.cantidad >= p.stock) { mostrarToast(`Stock máximo disponible: ${p.stock}.`, 'warning'); return; }
            existente.cantidad += cantidad;
        } else {
            carrito.push({ ...p, cantidad });
        }
        renderCarrito();
        mostrarToast(`✓ ${p.nombre} agregado.`);
    }

    function renderCarrito() {
        const lista = document.getElementById('lista-carrito');
        const placeholder = document.getElementById('carrito-placeholder');
        if (!lista) return;

        if (!carrito.length) {
            lista.innerHTML = '';
            if (placeholder) placeholder.style.display = '';
            actualizarTotales();
            return;
        }
        if (placeholder) placeholder.style.display = 'none';

        lista.innerHTML = carrito.map((item, i) => `
        <div class="d-flex align-items-center gap-2 py-2 border-bottom" data-idx="${i}">
          <div class="flex-grow-1">
            <div class="fw-bold small">${item.nombre}</div>
            <div class="text-muted" style="font-size:11px">${item.codigo} · S/ ${item.precio.toFixed(2)} c/u</div>
          </div>
          <div class="input-group input-group-sm" style="width:110px">
            <button class="btn btn-outline-secondary btn-qty" data-action="menos" data-idx="${i}">−</button>
            <input type="number" class="form-control text-center inp-qty" value="${item.cantidad}" min="1" max="${item.stock}" data-idx="${i}" style="width:40px">
            <button class="btn btn-outline-secondary btn-qty" data-action="mas" data-idx="${i}">+</button>
          </div>
          <div class="fw-bold text-success" style="min-width:65px;text-align:right">S/ ${(item.precio * item.cantidad).toFixed(2)}</div>
          <button class="btn btn-sm btn-link text-danger p-0 btn-quitar" data-idx="${i}"><i class="fa-solid fa-xmark"></i></button>
        </div>`).join('');

        actualizarTotales();
        actualizarBotones();
    }

    // Delegación en carrito
    document.addEventListener('click', e => {
        const btnQty  = e.target.closest('.btn-qty');
        const btnQuit = e.target.closest('.btn-quitar');

        if (btnQty) {
            const idx = +btnQty.dataset.idx;
            const prod = ProductosDB.buscarPorCodigo(carrito[idx].codigo);
            if (btnQty.dataset.action === 'mas') {
                if (carrito[idx].cantidad >= (prod?.stock || 9999)) { mostrarToast('Stock máximo.', 'warning'); return; }
                carrito[idx].cantidad++;
            } else {
                carrito[idx].cantidad--;
                if (carrito[idx].cantidad <= 0) carrito.splice(idx, 1);
            }
            renderCarrito();
        }

        if (btnQuit) {
            const idx = +btnQuit.dataset.idx;
            carrito.splice(idx, 1);
            renderCarrito();
        }
    });

    document.addEventListener('change', e => {
        const inp = e.target.closest('.inp-qty');
        if (!inp) return;
        const idx = +inp.dataset.idx;
        const val = parseInt(inp.value);
        const prod = ProductosDB.buscarPorCodigo(carrito[idx].codigo);
        if (isNaN(val) || val < 1) { carrito[idx].cantidad = 1; }
        else if (val > (prod?.stock || 9999)) { carrito[idx].cantidad = prod?.stock || 9999; mostrarToast('Stock máximo.', 'warning'); }
        else { carrito[idx].cantidad = val; }
        renderCarrito();
    });

    /* ============================================================
       TOTALES
    ============================================================ */
    function actualizarTotales() {
        const subtotalNeto = carrito.reduce((s, x) => s + x.precio * x.cantidad, 0);
        const igv          = subtotalNeto * 0.18;
        const total        = subtotalNeto + igv;

        const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = `S/ ${val.toFixed(2)}`; };
        set('total-subtotal', subtotalNeto);
        set('total-igv', igv);
        set('total-total', total);
        set('total-grande', total);

        // Habilitar imprimir solo si hay carrito
        const btnImprimir = document.getElementById('btn-imprimir');
        if (btnImprimir) {
            btnImprimir.disabled = carrito.length === 0 || ventaFinalizada;
        }
    }

    /* ============================================================
       MÉTODO DE PAGO
    ============================================================ */
    document.addEventListener('click', e => {
        const btn = e.target.closest('.btn-payment-method');
        if (!btn) return;
        document.querySelectorAll('.btn-payment-method').forEach(b => {
            b.classList.remove('active');
            b.querySelector('.fa-circle-check')?.remove();
        });
        btn.classList.add('active');
        metodoPago = btn.dataset.metodo || btn.querySelector('span')?.textContent.trim().toLowerCase().split('/')[0] || 'efectivo';
        const check = document.createElement('i');
        check.className = 'fa-solid fa-circle-check text-success ms-auto';
        btn.appendChild(check);
    });

    /* ============================================================
       BOTÓN AGREGAR + ESCANEAR
    ============================================================ */
    document.addEventListener('click', e => {
        // Agregar por código
        if (e.target.closest('#btn-agregar-codigo')) {
            const inp = document.getElementById('inp-codigo-prod');
            if (!inp?.value.trim()) { mostrarToast('Ingresa un código de producto.', 'warning'); return; }
            agregarProducto(inp.value.trim());
            inp.value = '';
        }

        // Escanear QR
        if (e.target.closest('#btn-escanear')) {
            document.getElementById('qr-manual-ventas').value = '';
            new bootstrap.Modal('#modalQRVentas').show();
        }
    });

    // Enter en input código
    document.addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.id === 'inp-codigo-prod') {
            const val = e.target.value.trim();
            if (val) { agregarProducto(val); e.target.value = ''; }
        }
    });

    /* ============================================================
       QR VENTAS
    ============================================================ */
    document.getElementById('modalQRVentas').addEventListener('shown.bs.modal', () => {
        const video  = document.getElementById('qr-video-ventas');
        const status = document.getElementById('qr-status-ventas');
        if (!navigator.mediaDevices?.getUserMedia) {
            status.textContent = '⚠ Cámara no disponible. Usa el campo manual.'; return;
        }
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(s => { qrStream = s; video.srcObject = s; status.textContent = '📷 Apunta al código QR del producto...'; })
            .catch(() => { status.textContent = '⚠ Sin acceso a cámara. Usa el campo manual.'; });
    });

    document.getElementById('modalQRVentas').addEventListener('hidden.bs.modal', () => {
        qrStream?.getTracks().forEach(t => t.stop()); qrStream = null;
    });

    document.getElementById('btn-qr-ventas-ok').addEventListener('click', () => {
        const val = document.getElementById('qr-manual-ventas').value.trim();
        if (!val) { mostrarToast('Ingresa el código.', 'warning'); return; }
        bootstrap.Modal.getInstance(document.getElementById('modalQRVentas')).hide();
        agregarProducto(val);
    });

    /* ============================================================
       PREVIEW TICKET
    ============================================================ */
    document.addEventListener('click', e => {
        if (!e.target.closest('#btn-preview')) return;
        if (!carrito.length) { mostrarToast('Agrega productos primero.', 'warning'); return; }

        const subtotal = carrito.reduce((s, x) => s + x.precio * x.cantidad, 0);
        const igv      = subtotal * 0.18;
        const total    = subtotal + igv;
        const tipo     = tabActual.toUpperCase();
        const num      = numComprobante();
        const fecha    = document.getElementById('inp-fecha')?.value || new Date().toLocaleString('es-PE');

        const nombreCliente = tabActual === 'proforma'
            ? `${document.getElementById('cli-apellidos')?.value || ''} ${document.getElementById('cli-nombres')?.value || ''}`.trim() || '—'
            : document.getElementById('cli-nombre-auto')?.value || '—';

        let ticket = `════════════════════════════
        AGROINPERU
════════════════════════════
${tipo}: ${num}
Fecha : ${fecha}
Cliente: ${nombreCliente}
────────────────────────────
PRODUCTO              CANT  TOTAL
`;
        carrito.forEach(x => {
            const nombre = x.nombre.substring(0, 18).padEnd(20);
            ticket += `${nombre}  ${String(x.cantidad).padStart(3)}  S/${(x.precio * x.cantidad).toFixed(2)}\n`;
        });
        ticket += `────────────────────────────
Subtotal :        S/ ${subtotal.toFixed(2)}
IGV (18%):        S/ ${igv.toFixed(2)}
TOTAL    :        S/ ${total.toFixed(2)}
Pago     :        ${metodoPago.toUpperCase()}
════════════════════════════
      ¡GRACIAS POR SU COMPRA!
════════════════════════════`;

        document.getElementById('ticket-preview').textContent = ticket;
        new bootstrap.Modal('#modalPreview').show();
    });

    /* ============================================================
       IMPRIMIR
    ============================================================ */
    function imprimirTicket() {
        if (!carrito.length) { mostrarToast('Sin productos en carrito.', 'warning'); return; }

        // Descontar stock
        let errorStock = null;
        for (const item of carrito) {
            const res = ProductosDB.descontarStock(item.codigo, item.cantidad);
            if (!res.ok) { errorStock = `${item.nombre}: ${res.msg}`; break; }
        }
        if (errorStock) { mostrarToast('⚠ ' + errorStock, 'danger'); return; }

        // Incrementar contador
        contadores[tabActual]++;
        guardarContadores();

        // Guardar en historial
        const historial = JSON.parse(localStorage.getItem('agroinperu_historial') || '[]');
        historial.unshift({
            numero: numComprobante().replace(/-\d+$/, `-${String(contadores[tabActual]-1).padStart(6,'0')}`),
            tipo: tabActual,
            cliente: tabActual === 'proforma'
                ? `${document.getElementById('cli-apellidos')?.value || ''} ${document.getElementById('cli-nombres')?.value || ''}`.trim()
                : document.getElementById('cli-nombre-auto')?.value || '—',
            items: [...carrito],
            total: carrito.reduce((s, x) => s + x.precio * x.cantidad, 0) * 1.18,
            metodo: metodoPago,
            fecha: new Date().toISOString(),
        });
        localStorage.setItem('agroinperu_historial', JSON.stringify(historial.slice(0, 100)));

        mostrarToast('✓ Venta registrada. Stock actualizado y sincronizado.', 'success');
        ventaFinalizada = true;

        // Imprimir con window.print del ticket
        const contenido = document.getElementById('ticket-preview')?.textContent;
        if (contenido) {
            const win = window.open('', '_blank', 'width=320,height=600');
            win.document.write(`<pre style="font-family:monospace;font-size:13px;padding:12px">${contenido}</pre>`);
            win.print();
            win.close();
        }

        // Reset
        setTimeout(() => {
            carrito = [];
            ventaFinalizada = false;
            actualizarComprobante();
            actualizarFormCliente();
            renderCarrito();
        }, 500);
    }

    document.addEventListener('click', e => {
        if (e.target.closest('#btn-imprimir') || e.target.closest('#btn-print-preview')) {
            bootstrap.Modal.getInstance(document.getElementById('modalPreview'))?.hide();
            imprimirTicket();
        }
    });

    /* ============================================================
       ANULAR
    ============================================================ */
    document.addEventListener('click', e => {
        if (!e.target.closest('#btn-anular')) return;
        if (!carrito.length && !document.getElementById('cli-numero-doc')?.value) {
            mostrarToast('No hay nada que anular.', 'warning'); return;
        }
        if (!confirm('¿Anular comprobante actual? Se vaciará el carrito y los datos del cliente.')) return;
        carrito = [];
        ventaFinalizada = false;
        renderCarrito();
        actualizarFormCliente();
        mostrarToast('Comprobante anulado.', 'danger');
    });

    /* ============================================================
       ACCESO RÁPIDO
    ============================================================ */
    document.addEventListener('click', e => {
        const item = e.target.closest('.quick-access-item');
        if (!item) return;
        const nombre = item.querySelector('span')?.textContent;
        const prod   = ProductosDB.getAll().find(p => p.nombre === nombre);
        if (prod) agregarProducto(prod.codigo);
    });

    /* ============================================================
       SINCRONIZACIÓN INVENTARIO → VENTAS
       Si inventario modifica productos en otra pestaña
    ============================================================ */
    window.addEventListener('storage', e => {
        if (e.key === 'agroinperu_productos') {
            actualizarAccesoRapido();
        }
    });

    function actualizarAccesoRapido() {
        const contenedor = document.querySelector('.quick-access-list');
        if (!contenedor) return;
        const productos = ProductosDB.getAll().slice(0, 6);
        contenedor.innerHTML = productos.map(p => `
        <div class="quick-access-item d-flex justify-content-between align-items-center py-2 border-bottom" style="cursor:pointer">
          <span class="small">${p.nombre}</span>
          <span class="fw-bold text-success small">S/ ${p.precio.toFixed(2)}</span>
        </div>`).join('');
    }

    /* ============================================================
       ACTUALIZAR BOTONES según estado
    ============================================================ */
    function actualizarBotones() {
        const tieneCarrito = carrito.length > 0;
        const btnImprimir  = document.getElementById('btn-imprimir');
        const btnPreview   = document.getElementById('btn-preview');
        if (btnImprimir) btnImprimir.disabled = !tieneCarrito || ventaFinalizada;
        if (btnPreview) btnPreview.disabled = !tieneCarrito;
    }

    /* ============================================================
       CARGA INICIAL — Reconstruir HTML dinámico
    ============================================================ */
    function init() {
        // Número comprobante
        const inpNumero = document.querySelector('input[value^="B001-"]');
        if (inpNumero) {
            inpNumero.id = 'inp-numero';
            inpNumero.value = numComprobante();
        }
        const inpFecha = document.querySelectorAll('input.bg-light')[1];
        if (inpFecha) inpFecha.id = 'inp-fecha';

        // Contenedor cliente
        const formCliente = document.querySelector('.row.g-3');
        if (formCliente) {
            formCliente.id = 'form-cliente-wrapper';
            // Envolver filas 3-6 en un div con id form-cliente
            const inputs = formCliente.querySelectorAll('.col-md-4, .col-md-8, .col-md-6');
            const wrap = document.createElement('div');
            wrap.className = 'row g-3';
            wrap.id = 'form-cliente';
            // Las filas 1-2 son número y fecha; del 3 en adelante son cliente
            let count = 0;
            inputs.forEach(el => {
                count++;
                if (count >= 3) wrap.appendChild(el.cloneNode(true));
            });
        }

        // Reconstruir el POS con IDs correctos para los eventos
        reconstruirPOS();
    }

    function reconstruirPOS() {
        // Área de productos escaneados
        const posContainer = document.querySelectorAll('.pos-container');
        if (!posContainer.length) return;

        // Container 1: datos comprobante
        const cont1 = posContainer[0];
        cont1.innerHTML = `
        <h6 class="fw-bold mb-3 text-muted text-uppercase small">Datos del Comprobante</h6>
        <div class="row g-3">
          <div class="col-md-6">
            <label class="form-label text-muted small mb-1">Número de comprobante autogenerado</label>
            <input type="text" id="inp-numero" class="form-control bg-light" value="${numComprobante()}" readonly>
          </div>
          <div class="col-md-6">
            <label class="form-label text-muted small mb-1">Fecha y Hora</label>
            <input type="text" id="inp-fecha" class="form-control bg-light" readonly>
          </div>
          <div id="form-cliente" class="col-12">
            <div class="row g-3" id="form-cliente-inner"></div>
          </div>
        </div>`;
        actualizarFecha();
        actualizarFormCliente();

        // Container 2: lista de productos
        const cont2 = posContainer[1];
        cont2.innerHTML = `
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h6 class="fw-bold m-0 text-muted text-uppercase small">Lista de Productos</h6>
          <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-20 px-3 py-2"><i class="fa-solid fa-barcode"></i> Escáner Listo</span>
        </div>
        <div class="input-group mb-3">
          <input type="text" id="inp-codigo-prod" class="form-control" placeholder="Escanear código o escribir código de producto...">
          <button class="btn btn-dark" id="btn-agregar-codigo">+ Agregar</button>
          <button class="btn btn-secondary" id="btn-escanear"><i class="fa-solid fa-expand"></i> Escanear</button>
        </div>
        <div id="lista-carrito"></div>
        <div id="carrito-placeholder" class="text-center text-muted py-4">
          <i class="fa-solid fa-basket-shopping fs-1 mb-2 d-block"></i>
          <span class="small">Sin productos. Escanea o busca productos.</span>
        </div>`;

        // Panel derecho: totales
        const contDer = posContainer[2];
        contDer.innerHTML = `
        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Subtotal</span><span id="total-subtotal">S/ 0.00</span></div>
        <div class="d-flex justify-content-between mb-2"><span class="text-muted">IGV (18%)</span><span id="total-igv">S/ 0.00</span></div>
        <div class="d-flex justify-content-between border-bottom pb-2 fw-bold"><span>Subtotal con IGV</span><span id="total-total">S/ 0.00</span></div>
        <div class="d-flex justify-content-between align-items-center my-3 bg-success bg-opacity-10 p-3 rounded">
          <span class="fw-bold text-success">TOTAL A PAGAR</span>
          <span class="fs-4 fw-bold text-success" id="total-grande">S/ 0.00</span>
        </div>
        <button class="btn-payment-method active mb-2 w-100 d-flex justify-content-between align-items-center p-3 border rounded" data-metodo="efectivo">
          <span><i class="fa-solid fa-money-bill-wave text-success me-2"></i>EFECTIVO</span>
          <i class="fa-solid fa-circle-check text-success"></i>
        </button>
        <button class="btn-payment-method mb-2 w-100 d-flex justify-content-between align-items-center p-3 border rounded bg-transparent" data-metodo="tarjeta">
          <span><i class="fa-solid fa-credit-card text-primary me-2"></i>TARJETA</span>
        </button>
        <button class="btn-payment-method mb-3 w-100 d-flex justify-content-between align-items-center p-3 border rounded bg-transparent" data-metodo="yape">
          <span><i class="fa-solid fa-mobile-screen-button text-info me-2"></i>YAPE/PLIN</span>
        </button>
        <button class="btn btn-outline-secondary w-100 mb-2 py-2" id="btn-preview"><i class="fa-solid fa-eye me-1"></i>PREVIEW TICKET</button>
        <button class="btn btn-outline-danger w-100 mb-2 py-2" id="btn-anular">Anular</button>
        <button class="btn btn-dark w-100 py-2" id="btn-imprimir" disabled><i class="fa-solid fa-print me-1"></i>Enviar a Imprimir</button>`;

        // Acceso rápido
        if (posContainer[3]) {
            posContainer[3].innerHTML = `
            <h6 class="fw-bold mb-3 text-muted text-uppercase small">Acceso Rápido</h6>
            <div class="quick-access-list">
              ${ProductosDB.getAll().slice(0,6).map(p => `
              <div class="quick-access-item d-flex justify-content-between align-items-center py-2 border-bottom" style="cursor:pointer">
                <span class="small">${p.nombre}</span>
                <span class="fw-bold text-success small">S/ ${p.precio.toFixed(2)}</span>
              </div>`).join('')}
            </div>`;
        }

        // Reconstruir form-cliente dentro del nuevo HTML
        actualizarFormCliente();
    }

    /* ============================================================
       Alias para actualizarFormCliente (el div tiene id form-cliente)
    ============================================================ */
    const _actualizarFormCliente = actualizarFormCliente;
    actualizarFormCliente = function () {
        const cont = document.getElementById('form-cliente');
        if (!cont) return;

        if (tabActual === 'proforma') {
            cont.innerHTML = `
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-muted small mb-1">Apellidos del Cliente</label>
                <input type="text" class="form-control" id="cli-apellidos" placeholder="Apellidos">
              </div>
              <div class="col-md-6">
                <label class="form-label text-muted small mb-1">Nombres del Cliente</label>
                <input type="text" class="form-control" id="cli-nombres" placeholder="Nombres">
              </div>
            </div>`;
            return;
        }

        const opcs = tabActual === 'boleta'
            ? `<option value="DNI">DNI</option><option value="RUC">RUC</option><option value="sin_doc">Sin Documento</option><option value="razon">Razón Social</option>`
            : `<option value="RUC">RUC</option>`;

        cont.innerHTML = `
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label text-muted small mb-1">Tipo de Documento</label>
            <select class="form-select" id="cli-tipo-doc">${opcs}</select>
          </div>
          <div class="col-md-8">
            <label class="form-label text-muted small mb-1">${tabActual === 'factura' ? 'Número de RUC' : 'Número según tipo'}</label>
            <div class="input-group">
              <input type="text" class="form-control" id="cli-numero-doc" placeholder="${tabActual === 'factura' ? 'RUC (11 dígitos)' : 'Número de documento'}">
              <button class="btn btn-success" type="button" id="btn-buscar-cliente"><i class="fa-solid fa-magnifying-glass"></i> Buscar</button>
            </div>
          </div>
          <div class="col-md-6">
            <label class="form-label text-muted small mb-1">Nombre / Razón Social</label>
            <input type="text" class="form-control bg-light" id="cli-nombre-auto" placeholder="Se completa automáticamente" readonly>
          </div>
          <div class="col-md-6">
            <label class="form-label text-muted small mb-1">Dirección</label>
            <input type="text" class="form-control bg-light" id="cli-dir-auto" placeholder="Se completa automáticamente" readonly>
          </div>
        </div>`;

        document.getElementById('cli-tipo-doc')?.addEventListener('change', () => {
            const tipo = document.getElementById('cli-tipo-doc').value;
            const phs  = { DNI:'DNI (8 dígitos)', RUC:'RUC (11 dígitos)', sin_doc:'Sin Documento', razon:'Razón Social' };
            document.getElementById('cli-numero-doc').placeholder = phs[tipo] || 'Número';
            document.getElementById('cli-nombre-auto').value = '';
            document.getElementById('cli-dir-auto').value = '';
        });

        document.getElementById('btn-buscar-cliente')?.addEventListener('click', buscarCliente);
    };

    init();
});