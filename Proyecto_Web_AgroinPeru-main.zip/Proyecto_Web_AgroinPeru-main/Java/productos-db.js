/**
 * productos-db.js — AgroinPeru
 * Base de datos compartida entre Inventario y Ventas.
 * Usa localStorage para persistencia y sincronización entre pestañas.
 */

const STORAGE_KEY = 'agroinperu_productos';

const productosIniciales = [
    { codigo: "FER001", nombre: "Pala Recta",           categoria: "Herramientas", precio: 45.00, stock: 25 },
    { codigo: "FER002", nombre: "Rastrillo Metálico",   categoria: "Herramientas", precio: 35.50, stock: 18 },
    { codigo: "FER003", nombre: "Manguera 20m",         categoria: "Riego",        precio: 65.00, stock: 30 },
    { codigo: "FER004", nombre: "Tijera de Podar",      categoria: "Jardinería",   precio: 28.90, stock: 15 },
    { codigo: "FER005", nombre: "Fertilizante Orgánico",categoria: "Abonos",       precio: 22.00, stock: 50 },
    { codigo: "FER006", nombre: "Semillas de Tomate",   categoria: "Semillas",     precio:  8.50, stock: 100 },
    { codigo: "FER007", nombre: "Semillas de Lechuga",  categoria: "Semillas",     precio:  6.50, stock: 80 },
    { codigo: "FER008", nombre: "Pulverizador 5L",      categoria: "Fumigación",   precio: 55.00, stock: 12 },
    { codigo: "FER009", nombre: "Guantes de Trabajo",   categoria: "Seguridad",    precio: 12.00, stock: 60 },
    { codigo: "FER010", nombre: "Regadera Plástica",    categoria: "Riego",        precio: 18.00, stock: 22 },
];

const ProductosDB = (() => {

    /* ── Inicializar localStorage solo si está vacío ── */
    function _init() {
        if (!localStorage.getItem(STORAGE_KEY)) {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(productosIniciales));
        }
    }

    function _leer() {
        _init();
        try {
            return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
        } catch {
            return [...productosIniciales];
        }
    }

    function _guardar(lista) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(lista));
    }

    /* ── API pública ── */
    return {

        /** Devuelve todos los productos */
        getAll() {
            return _leer();
        },

        /** Busca por código (insensible a mayúsculas) */
        buscarPorCodigo(codigo) {
            return _leer().find(p => p.codigo === codigo.toUpperCase()) || null;
        },

        /** Agrega un producto nuevo */
        agregar(prod) {
            const lista = _leer();
            if (lista.find(p => p.codigo === prod.codigo.toUpperCase())) {
                return { ok: false, msg: `El código "${prod.codigo}" ya existe.` };
            }
            lista.push({ ...prod, codigo: prod.codigo.toUpperCase() });
            _guardar(lista);
            return { ok: true };
        },

        /** Actualiza un producto existente */
        actualizar(codigoOriginal, prod) {
            const lista = _leer();
            const idx   = lista.findIndex(p => p.codigo === codigoOriginal.toUpperCase());
            if (idx === -1) return { ok: false, msg: 'Producto no encontrado.' };
            lista[idx] = { ...prod, codigo: prod.codigo.toUpperCase() };
            _guardar(lista);
            return { ok: true };
        },

        /** Elimina un producto por código */
        eliminar(codigo) {
            const lista = _leer().filter(p => p.codigo !== codigo.toUpperCase());
            _guardar(lista);
            return { ok: true };
        },

        /**
         * Descuenta stock al realizar una venta.
         * Retorna { ok, msg }
         */
        descontarStock(codigo, cantidad) {
            const lista = _leer();
            const prod  = lista.find(p => p.codigo === codigo.toUpperCase());
            if (!prod)              return { ok: false, msg: `Producto "${codigo}" no encontrado.` };
            if (prod.stock < cantidad) return { ok: false, msg: `Stock insuficiente para "${prod.nombre}" (disponible: ${prod.stock}).` };
            prod.stock -= cantidad;
            _guardar(lista);
            return { ok: true };
        },

        /** Resetea la BD a los productos iniciales (útil para pruebas) */
        resetear() {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(productosIniciales));
        },
    };
})();